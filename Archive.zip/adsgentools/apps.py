from django.apps import AppConfig


class AdsgentoolsConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'adsgentools'
    verbose_name = 'Ads Generator Tools'
